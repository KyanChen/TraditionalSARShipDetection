#include "LevirSAR.h"

class FineDetection
{
private:
    HOGDescriptor *m_hog;
	double *m_w;

	float get_hog_score(Mat& img);

public:
    FineDetection();
    ~FineDetection();

    void run(Mat &img, vector<Rect> &targets, vector<Rect> &final_targets);
};
